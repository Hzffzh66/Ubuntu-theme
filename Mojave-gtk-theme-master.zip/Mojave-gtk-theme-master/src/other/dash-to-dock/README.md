## WhiteSur dash-to-dock theme

## Installation

### Install tips

Usage:  `./install.sh`  **[OPTIONS...]**

|  OPTIONS:           | |
|:--------------------|:-------------|
| with no option      | it'll run a terminal dialog to install the theme |
|-d, --dark           | install dark version |
|-l, --light          | install light version |
|-h, --help           | Show this help|

### Manual installation

Copy `../src/other/dash-to-dock/stylesheet.css` to `../.local/share/gnome-shell/extensions/dash-to-dock@micxgx.gmail.com`

then you can:

1. Open `Dash to Dock Settings`.
2. Go to `[Appearance]` > `[Use built-in theme]` and turn it on.
3. Restart Dash to Dock or gnome-shell.
4. Be happy with your new dash-to-dock theme.
